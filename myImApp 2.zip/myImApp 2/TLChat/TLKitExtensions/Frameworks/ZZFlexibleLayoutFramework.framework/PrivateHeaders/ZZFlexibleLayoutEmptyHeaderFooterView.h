#import <UIKit/UIKit.h>

@interface ZZFlexibleLayoutEmptyHeaderFooterView : UICollectionReusableView

@end
