
#import "TLLaunchManager+UserData.h"


@implementation TLLaunchManager (UserData)

- (void)initUserData
{
    NSNumber *lastRunDate = [[NSUserDefaults standardUserDefaults] objectForKey:@"lastRunDate"];
    
    
}

@end

