
#import "TLLaunchManager.h"

@interface TLLaunchManager (UserData)

/// 初始化用户信息
- (void)initUserData;

@end
