
#import "TLViewController.h"

@interface TLAccountViewController : TLViewController

@property (nonatomic, copy) void (^loginSuccess)();

@end
