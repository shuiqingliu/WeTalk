
#import "TLViewController.h"

@interface TLLoginViewController : TLViewController

@property (nonatomic, copy) void (^loginSuccess)();

@end
