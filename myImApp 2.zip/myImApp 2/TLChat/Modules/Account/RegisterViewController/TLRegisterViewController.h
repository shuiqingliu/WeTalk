

#import "TLViewController.h"

@interface TLRegisterViewController : TLViewController

@property (nonatomic, copy) void (^registerSuccess)();

@end
